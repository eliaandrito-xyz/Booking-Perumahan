// Utility Functions
const $ = (selector, context = document) => context.querySelector(selector);
const $$ = (selector, context = document) => context.querySelectorAll(selector);

// DOM Ready Helper
const domReady = (callback) => {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', callback);
    } else {
        callback();
    }
};

// Animation Observer
const observeElements = () => {
    if (!('IntersectionObserver' in window)) {
        // Fallback jika IntersectionObserver tidak support
        $$('.card, .stat-card, .table-container').forEach(el => {
            el.style.animationPlayState = 'running';
        });
        return;
    }

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
                entry.target.style.animationPlayState = 'running';
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '50px'
    });

    $$('.card, .stat-card, .table-container').forEach(el => {
        if (!el.classList.contains('animated')) {
            el.style.animationPlayState = 'paused';
            observer.observe(el);
        }
    });
};

// Form Validation dengan validasi lebih lengkap
const validateForm = (formId, options = {}) => {
    const form = $(formId);
    if (!form) return { isValid: false, errors: [] };

    const inputs = form.querySelectorAll('input, select, textarea');
    const errors = [];
    let isValid = true;

    inputs.forEach(input => {
        // Skip hidden inputs
        if (input.type === 'hidden') return;

        const value = input.value.trim();
        const isRequired = input.hasAttribute('required');
        const validationType = input.getAttribute('data-validation');
        
        // Clear previous errors
        clearFieldError(input);

        // Required validation
        if (isRequired && !value) {
            showFieldError(input, options.messages?.required || 'Field ini wajib diisi');
            errors.push({ field: input.name, message: 'Field wajib diisi' });
            isValid = false;
            return;
        }

        // Skip jika tidak ada value dan tidak required
        if (!value) return;

        // Email validation
        if (validationType === 'email' || input.type === 'email') {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                showFieldError(input, options.messages?.email || 'Format email tidak valid');
                errors.push({ field: input.name, message: 'Format email tidak valid' });
                isValid = false;
            }
        }

        // Number validation
        if (validationType === 'number' || input.type === 'number') {
            if (isNaN(value)) {
                showFieldError(input, options.messages?.number || 'Harus berupa angka');
                errors.push({ field: input.name, message: 'Harus berupa angka' });
                isValid = false;
            }
        }

        // Min length validation
        const minLength = input.getAttribute('minlength');
        if (minLength && value.length < parseInt(minLength)) {
            showFieldError(input, `Minimal ${minLength} karakter`);
            errors.push({ field: input.name, message: `Minimal ${minLength} karakter` });
            isValid = false;
        }

        // Max length validation
        const maxLength = input.getAttribute('maxlength');
        if (maxLength && value.length > parseInt(maxLength)) {
            showFieldError(input, `Maksimal ${maxLength} karakter`);
            errors.push({ field: input.name, message: `Maksimal ${maxLength} karakter` });
            isValid = false;
        }

        // Pattern validation
        const pattern = input.getAttribute('pattern');
        if (pattern) {
            const regex = new RegExp(pattern);
            if (!regex.test(value)) {
                showFieldError(input, options.messages?.pattern || 'Format tidak sesuai');
                errors.push({ field: input.name, message: 'Format tidak sesuai' });
                isValid = false;
            }
        }
    });

    return { isValid, errors };
};

// Real-time form validation
const enableRealTimeValidation = (formId) => {
    const form = $(formId);
    if (!form) return;

    const inputs = form.querySelectorAll('input, select, textarea');
    
    inputs.forEach(input => {
        // Validasi saat blur
        input.addEventListener('blur', () => {
            if (input.hasAttribute('required') || input.value.trim()) {
                validateForm(formId);
            }
        });

        // Hapus error saat input
        input.addEventListener('input', () => {
            if (input.style.borderColor === 'rgb(220, 53, 69)') {
                clearFieldError(input);
            }
        });
    });
};

const showFieldError = (field, message) => {
    clearFieldError(field);
    
    field.classList.add('error');
    field.style.borderColor = '#dc3545';
    field.style.boxShadow = '0 0 0 0.2rem rgba(220, 53, 69, 0.25)';
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    
    field.parentNode.appendChild(errorDiv);
    
    // Scroll ke field error jika diperlukan
    const rect = field.getBoundingClientRect();
    if (rect.top < 0 || rect.bottom > window.innerHeight) {
        field.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
};

const clearFieldError = (field) => {
    field.classList.remove('error');
    field.style.borderColor = '';
    field.style.boxShadow = '';
    
    const errorDiv = field.parentNode.querySelector('.field-error');
    if (errorDiv) {
        errorDiv.remove();
    }
};

// Alert System dengan opsi lebih banyak
const showAlert = (message, options = {}) => {
    const {
        type = 'info',
        duration = 5000,
        position = 'top',
        dismissible = true,
        icon = true
    } = options;

    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.setAttribute('role', 'alert');
    
    const icons = {
        success: '✓',
        error: '✗',
        warning: '⚠',
        info: 'ℹ'
    };
    
    alertDiv.innerHTML = `
        ${icon ? `<span class="alert-icon">${icons[type] || icons.info}</span>` : ''}
        <span class="alert-message">${message}</span>
        ${dismissible ? '<button class="alert-close">&times;</button>' : ''}
    `;
    
    // Styling
    Object.assign(alertDiv.style, {
        position: 'fixed',
        [position]: '20px',
        left: '50%',
        transform: 'translateX(-50%)',
        maxWidth: '500px',
        width: '90%',
        zIndex: '9999',
        animation: 'slideInDown 0.3s ease-out'
    });

    document.body.appendChild(alertDiv);

    // Close button handler
    if (dismissible) {
        const closeBtn = alertDiv.querySelector('.alert-close');
        closeBtn.onclick = () => removeAlert(alertDiv);
    }

    // Auto remove jika ada duration
    if (duration > 0) {
        setTimeout(() => removeAlert(alertDiv), duration);
    }

    return alertDiv;
};

const removeAlert = (alertDiv) => {
    alertDiv.style.animation = 'slideOutUp 0.3s ease-out';
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.parentNode.removeChild(alertDiv);
        }
    }, 300);
};

// Toast notification (alert kecil)
const showToast = (message, type = 'info', duration = 3000) => {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    Object.assign(toast.style, {
        position: 'fixed',
        bottom: '20px',
        right: '20px',
        padding: '10px 20px',
        background: type === 'success' ? '#28a745' : 
                   type === 'error' ? '#dc3545' : 
                   type === 'warning' ? '#ffc107' : '#17a2b8',
        color: 'white',
        borderRadius: '5px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
        zIndex: '9999',
        animation: 'slideInRight 0.3s ease-out'
    });

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.animation = 'slideOutRight 0.3s ease-out';
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, duration);
};

// Loading State dengan progress bar support
const showLoading = (element, options = {}) => {
    const {
        text = 'Loading...',
        overlay = true,
        spinner = true,
        progress = false
    } = options;

    const loadingDiv = document.createElement('div');
    loadingDiv.className = 'loading-overlay';
    
    let loadingHTML = '';
    
    if (spinner) {
        loadingHTML += '<div class="loading-spinner"></div>';
    }
    
    if (text) {
        loadingHTML += `<div class="loading-text">${text}</div>`;
    }
    
    if (progress) {
        loadingHTML += `
            <div class="loading-progress">
                <div class="loading-progress-bar"></div>
            </div>
        `;
    }
    
    loadingDiv.innerHTML = loadingHTML;

    Object.assign(loadingDiv.style, {
        position: 'absolute',
        top: '0',
        left: '0',
        right: '0',
        bottom: '0',
        background: overlay ? 'rgba(255, 255, 255, 0.9)' : 'transparent',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: '999',
        borderRadius: 'inherit'
    });

    // Styling untuk spinner
    if (spinner) {
        const spinnerStyle = document.createElement('style');
        spinnerStyle.textContent = `
            .loading-spinner {
                width: 40px;
                height: 40px;
                border: 3px solid #f3f3f3;
                border-top: 3px solid var(--accent-gold, #ffd700);
                border-radius: 50%;
                animation: spin 1s linear infinite;
                margin-bottom: 10px;
            }
        `;
        document.head.appendChild(spinnerStyle);
    }

    element.style.position = 'relative';
    element.appendChild(loadingDiv);

    return {
        updateProgress: (percent) => {
            const progressBar = loadingDiv.querySelector('.loading-progress-bar');
            if (progressBar) {
                progressBar.style.width = `${percent}%`;
            }
        },
        updateText: (newText) => {
            const textElement = loadingDiv.querySelector('.loading-text');
            if (textElement) {
                textElement.textContent = newText;
            }
        },
        hide: () => {
            loadingDiv.style.opacity = '0';
            loadingDiv.style.transition = 'opacity 0.3s ease';
            setTimeout(() => {
                if (loadingDiv.parentNode) {
                    loadingDiv.parentNode.removeChild(loadingDiv);
                }
            }, 300);
        }
    };
};

// AJAX Helper dengan retry dan timeout
const ajaxRequest = async (url, options = {}) => {
    const {
        method = 'GET',
        headers = {},
        body = null,
        timeout = 30000,
        retries = 3
    } = options;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    const requestOptions = {
        method,
        headers: {
            'Content-Type': 'application/json',
            ...headers
        },
        signal: controller.signal,
        ...(body && { body: JSON.stringify(body) })
    };

    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            const response = await fetch(url, requestOptions);
            clearTimeout(timeoutId);

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`HTTP ${response.status}: ${errorText || response.statusText}`);
            }

            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                return await response.json();
            } else {
                return await response.text();
            }
        } catch (error) {
            if (attempt === retries) {
                clearTimeout(timeoutId);
                throw error;
            }
            
            // Wait sebelum retry (exponential backoff)
            await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
        }
    }
};

// Upload file dengan progress
const uploadFile = async (url, file, options = {}) => {
    const {
        onProgress,
        onComplete,
        onError
    } = options;

    const formData = new FormData();
    formData.append('file', file);

    const xhr = new XMLHttpRequest();

    return new Promise((resolve, reject) => {
        xhr.upload.addEventListener('progress', (event) => {
            if (event.lengthComputable && onProgress) {
                const percentComplete = (event.loaded / event.total) * 100;
                onProgress(percentComplete);
            }
        });

        xhr.addEventListener('load', () => {
            if (xhr.status >= 200 && xhr.status < 300) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (onComplete) onComplete(response);
                    resolve(response);
                } catch (e) {
                    if (onComplete) onComplete(xhr.responseText);
                    resolve(xhr.responseText);
                }
            } else {
                const error = new Error(`Upload failed: ${xhr.statusText}`);
                if (onError) onError(error);
                reject(error);
            }
        });

        xhr.addEventListener('error', () => {
            const error = new Error('Upload failed');
            if (onError) onError(error);
            reject(error);
        });

        xhr.open('POST', url);
        
        // Set custom headers jika ada
        if (options.headers) {
            Object.keys(options.headers).forEach(key => {
                xhr.setRequestHeader(key, options.headers[key]);
            });
        }

        xhr.send(formData);
    });
};

// Modal System yang lebih robust
class Modal {
    constructor(options = {}) {
        this.options = {
            title: '',
            content: '',
            size: 'md', // sm, md, lg, xl
            showClose: true,
            backdrop: true,
            keyboard: true,
            onShow: null,
            onHide: null,
            ...options
        };

        this.id = `modal-${Date.now()}`;
        this.isVisible = false;
    }

    show() {
        if (this.isVisible) return;

        const modal = document.createElement('div');
        modal.id = this.id;
        modal.className = 'modal';

        // Overlay
        if (this.options.backdrop) {
            const overlay = document.createElement('div');
            overlay.className = 'modal-backdrop';
            overlay.onclick = () => this.hide();
            modal.appendChild(overlay);
        }

        // Content
        const modalDialog = document.createElement('div');
        modalDialog.className = `modal-dialog modal-${this.options.size}`;
        
        const modalContent = document.createElement('div');
        modalContent.className = 'modal-content';

        // Header
        if (this.options.title || this.options.showClose) {
            const modalHeader = document.createElement('div');
            modalHeader.className = 'modal-header';
            
            if (this.options.title) {
                const title = document.createElement('h3');
                title.className = 'modal-title';
                title.textContent = this.options.title;
                modalHeader.appendChild(title);
            }

            if (this.options.showClose) {
                const closeBtn = document.createElement('button');
                closeBtn.type = 'button';
                closeBtn.className = 'modal-close';
                closeBtn.innerHTML = '&times;';
                closeBtn.onclick = () => this.hide();
                modalHeader.appendChild(closeBtn);
            }

            modalContent.appendChild(modalHeader);
        }

        // Body
        const modalBody = document.createElement('div');
        modalBody.className = 'modal-body';
        
        if (typeof this.options.content === 'string') {
            modalBody.innerHTML = this.options.content;
        } else if (this.options.content instanceof HTMLElement) {
            modalBody.appendChild(this.options.content);
        }
        
        modalContent.appendChild(modalBody);

        // Footer jika ada actions
        if (this.options.actions && this.options.actions.length > 0) {
            const modalFooter = document.createElement('div');
            modalFooter.className = 'modal-footer';
            
            this.options.actions.forEach(action => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = `btn ${action.class || 'btn-secondary'}`;
                btn.textContent = action.text;
                btn.onclick = () => {
                    if (action.onclick) action.onclick();
                    if (action.close !== false) this.hide();
                };
                modalFooter.appendChild(btn);
            });
            
            modalContent.appendChild(modalFooter);
        }

        modalDialog.appendChild(modalContent);
        modal.appendChild(modalDialog);

        // Add to DOM
        document.body.appendChild(modal);
        document.body.style.overflow = 'hidden';

        // Add CSS jika belum ada
        this.addStyles();

        // Keyboard events
        if (this.options.keyboard) {
            this.keyboardHandler = (e) => {
                if (e.key === 'Escape') this.hide();
            };
            document.addEventListener('keydown', this.keyboardHandler);
        }

        // Trigger onShow callback
        if (this.options.onShow) {
            setTimeout(() => this.options.onShow(), 10);
        }

        this.isVisible = true;
        return this;
    }

    hide() {
        const modal = $(`#${this.id}`);
        if (!modal) return;

        modal.style.animation = 'fadeOut 0.3s ease-out';
        
        setTimeout(() => {
            if (modal.parentNode) {
                modal.parentNode.removeChild(modal);
            }
            
            document.body.style.overflow = '';
            
            if (this.keyboardHandler) {
                document.removeEventListener('keydown', this.keyboardHandler);
            }

            // Trigger onHide callback
            if (this.options.onHide) {
                this.options.onHide();
            }

            this.isVisible = false;
        }, 300);
    }

    addStyles() {
        if ($('#modal-styles')) return;

        const styles = `
            .modal {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                z-index: 1050;
                display: flex;
                align-items: center;
                justify-content: center;
                animation: fadeIn 0.3s ease-out;
            }
            
            .modal-backdrop {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
            }
            
            .modal-dialog {
                position: relative;
                width: 100%;
                max-width: 500px;
                margin: 1rem;
                z-index: 1051;
            }
            
            .modal-sm {
                max-width: 300px;
            }
            
            .modal-lg {
                max-width: 800px;
            }
            
            .modal-xl {
                max-width: 1140px;
            }
            
            .modal-content {
                background: white;
                border-radius: 15px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
                animation: slideInDown 0.3s ease-out;
                overflow: hidden;
            }
            
            .modal-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 1.5rem;
                border-bottom: 2px solid #f0f0f0;
            }
            
            .modal-title {
                margin: 0;
                font-size: 1.5rem;
                color: var(--primary-black);
            }
            
            .modal-close {
                background: none;
                border: none;
                font-size: 1.5rem;
                cursor: pointer;
                padding: 0;
                width: 30px;
                height: 30px;
                display: flex;
                align-items: center;
                justify-content: center;
                color: var(--gray-dark);
                transition: color 0.3s ease;
            }
            
            .modal-close:hover {
                color: var(--primary-black);
            }
            
            .modal-body {
                padding: 1.5rem;
                max-height: 60vh;
                overflow-y: auto;
            }
            
            .modal-footer {
                display: flex;
                gap: 1rem;
                justify-content: flex-end;
                padding: 1.5rem;
                border-top: 2px solid #f0f0f0;
            }
        `;

        const styleEl = document.createElement('style');
        styleEl.id = 'modal-styles';
        styleEl.textContent = styles;
        document.head.appendChild(styleEl);
    }
}

// Confirm Dialog menggunakan Modal class
const confirmDialog = (message, options = {}) => {
    return new Promise((resolve) => {
        const modal = new Modal({
            title: options.title || 'Konfirmasi',
            content: `<p>${message}</p>`,
            size: 'sm',
            showClose: false,
            backdrop: true,
            keyboard: true,
            actions: [
                {
                    text: options.cancelText || 'Batal',
                    class: 'btn-secondary',
                    onclick: () => resolve(false)
                },
                {
                    text: options.confirmText || 'Ya, Lanjutkan',
                    class: 'btn-primary',
                    onclick: () => resolve(true)
                }
            ]
        });
        
        modal.show();
    });
};

// Data Table Enhancement dengan fitur lengkap
const enhanceTable = (tableSelector, options = {}) => {
    const table = $(tableSelector);
    if (!table) return null;

    const config = {
        searchable: true,
        sortable: true,
        pagination: false,
        pageSize: 10,
        exportable: false,
        ...options
    };

    const wrapper = document.createElement('div');
    wrapper.className = 'table-enhanced';
    table.parentNode.insertBefore(wrapper, table);
    wrapper.appendChild(table);

    // Add search functionality
    if (config.searchable) {
        const searchContainer = document.createElement('div');
        searchContainer.className = 'table-search';
        searchContainer.style.cssText = `
            display: flex;
            gap: 1rem;
            margin-bottom: 1rem;
            flex-wrap: wrap;
        `;

        const searchInput = document.createElement('input');
        searchInput.type = 'text';
        searchInput.placeholder = 'Cari data...';
        searchInput.className = 'form-control';
        searchInput.style.flex = '1';
        searchInput.minLength = '200px';

        searchContainer.appendChild(searchInput);
        wrapper.insertBefore(searchContainer, table);

        const rows = table.querySelectorAll('tbody tr');
        const searchableColumns = [];

        // Tentukan kolom yang bisa dicari
        table.querySelectorAll('thead th').forEach((th, index) => {
            if (!th.hasAttribute('data-no-search')) {
                searchableColumns.push(index);
            }
        });

        searchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            
            rows.forEach(row => {
                let matches = false;
                
                searchableColumns.forEach(colIndex => {
                    const cell = row.cells[colIndex];
                    if (cell && cell.textContent.toLowerCase().includes(searchTerm)) {
                        matches = true;
                    }
                });
                
                row.style.display = matches ? '' : 'none';
            });

            // Update pagination jika aktif
            if (config.pagination) {
                updatePagination();
            }
        });
    }

    // Add sorting functionality
    if (config.sortable) {
        const headers = table.querySelectorAll('thead th');
        headers.forEach((header, index) => {
            if (header.hasAttribute('data-no-sort')) return;
            
            header.style.cursor = 'pointer';
            header.style.userSelect = 'none';
            header.classList.add('sortable');
            
            // Add sort indicator
            const sortIndicator = document.createElement('span');
            sortIndicator.className = 'sort-indicator';
            sortIndicator.innerHTML = '↕';
            sortIndicator.style.marginLeft = '5px';
            sortIndicator.style.opacity = '0.5';
            header.appendChild(sortIndicator);
            
            header.addEventListener('click', () => {
                const tbody = table.querySelector('tbody');
                const rowsArray = Array.from(tbody.querySelectorAll('tr:not([style*="none"])'));
                
                const currentSort = header.getAttribute('data-sort') || 'none';
                let newSort = 'asc';
                
                if (currentSort === 'asc') {
                    newSort = 'desc';
                } else if (currentSort === 'desc') {
                    newSort = 'none';
                }
                
                // Reset semua header
                headers.forEach(h => {
                    h.setAttribute('data-sort', 'none');
                    h.classList.remove('sort-asc', 'sort-desc');
                });
                
                if (newSort !== 'none') {
                    header.setAttribute('data-sort', newSort);
                    header.classList.add(`sort-${newSort}`);
                    
                    rowsArray.sort((a, b) => {
                        const aText = a.cells[index]?.textContent.trim() || '';
                        const bText = b.cells[index]?.textContent.trim() || '';
                        
                        const aNum = parseFloat(aText.replace(/[^0-9.-]+/g, ''));
                        const bNum = parseFloat(bText.replace(/[^0-9.-]+/g, ''));
                        
                        let comparison = 0;
                        if (!isNaN(aNum) && !isNaN(bNum)) {
                            comparison = aNum - bNum;
                        } else {
                            comparison = aText.localeCompare(bText, undefined, { numeric: true });
                        }
                        
                        return newSort === 'asc' ? comparison : -comparison;
                    });
                    
                    rowsArray.forEach(row => tbody.appendChild(row));
                } else {
                    // Kembalikan ke urutan asli
                    const originalRows = Array.from(table.querySelectorAll('tbody tr'));
                    originalRows.forEach(row => tbody.appendChild(row));
                }
                
                // Update pagination jika aktif
                if (config.pagination) {
                    updatePagination();
                }
            });
        });
    }

    // Add pagination
    if (config.pagination) {
        let currentPage = 1;
        const totalRows = table.querySelectorAll('tbody tr').length;
        const totalPages = Math.ceil(totalRows / config.pageSize);
        
        const paginationContainer = document.createElement('div');
        paginationContainer.className = 'table-pagination';
        paginationContainer.style.cssText = `
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 1rem;
            padding: 1rem;
            background: var(--white);
            border-radius: 10px;
            box-shadow: var(--shadow);
        `;
        
        wrapper.appendChild(paginationContainer);
        
        const updatePagination = () => {
            const visibleRows = table.querySelectorAll('tbody tr:not([style*="none"])');
            const startIndex = (currentPage - 1) * config.pageSize;
            const endIndex = startIndex + config.pageSize;
            
            visibleRows.forEach((row, index) => {
                row.style.display = (index >= startIndex && index < endIndex) ? '' : 'none';
            });
            
            updatePaginationUI();
        };
        
        const updatePaginationUI = () => {
            paginationContainer.innerHTML = '';
            
            // Page info
            const pageInfo = document.createElement('span');
            pageInfo.className = 'page-info';
            pageInfo.textContent = `Halaman ${currentPage} dari ${totalPages}`;
            
            // Page controls
            const controls = document.createElement('div');
            controls.className = 'page-controls';
            controls.style.display = 'flex';
            controls.style.gap = '0.5rem';
            
            const prevBtn = document.createElement('button');
            prevBtn.className = 'btn btn-secondary';
            prevBtn.innerHTML = '&laquo;';
            prevBtn.disabled = currentPage === 1;
            prevBtn.onclick = () => {
                if (currentPage > 1) {
                    currentPage--;
                    updatePagination();
                }
            };
            
            const nextBtn = document.createElement('button');
            nextBtn.className = 'btn btn-secondary';
            nextBtn.innerHTML = '&raquo;';
            nextBtn.disabled = currentPage === totalPages;
            nextBtn.onclick = () => {
                if (currentPage < totalPages) {
                    currentPage++;
                    updatePagination();
                }
            };
            
            controls.appendChild(prevBtn);
            controls.appendChild(nextBtn);
            
            paginationContainer.appendChild(pageInfo);
            paginationContainer.appendChild(controls);
        };
        
        updatePagination();
    }

    // Add export functionality
    if (config.exportable) {
        const exportBtn = document.createElement('button');
        exportBtn.className = 'btn btn-success';
        exportBtn.innerHTML = '📥 Export';
        exportBtn.style.marginLeft = 'auto';
        
        const searchContainer = wrapper.querySelector('.table-search');
        if (searchContainer) {
            searchContainer.appendChild(exportBtn);
        }
        
        exportBtn.onclick = () => {
            const rows = [];
            const headers = [];
            
            // Get headers
            table.querySelectorAll('thead th').forEach(th => {
                headers.push(th.textContent.trim());
            });
            
            // Get rows
            table.querySelectorAll('tbody tr:not([style*="none"])').forEach(tr => {
                const row = [];
                tr.querySelectorAll('td').forEach(td => {
                    row.push(td.textContent.trim());
                });
                rows.push(row);
            });
            
            // Create CSV
            let csvContent = headers.join(',') + '\n';
            rows.forEach(row => {
                csvContent += row.map(cell => `"${cell.replace(/"/g, '""')}"`).join(',') + '\n';
            });
            
            // Download
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = `export-${new Date().toISOString().split('T')[0]}.csv`;
            link.click();
        };
    }

    return {
        refresh: () => {
            if (config.pagination) {
                updatePagination();
            }
        },
        search: (term) => {
            const searchInput = wrapper.querySelector('input[type="text"]');
            if (searchInput) {
                searchInput.value = term;
                searchInput.dispatchEvent(new Event('input'));
            }
        }
    };
};

// Auto-save functionality dengan debounce
const autoSave = (formSelector, saveUrl, options = {}) => {
    const form = $(formSelector);
    if (!form) return null;

    const config = {
        interval: 30000,
        minChanges: 1,
        confirmBeforeUnload: true,
        onSave: null,
        onError: null,
        ...options
    };

    let saveTimeout;
    let changesCount = 0;
    let isSaving = false;

    const saveData = async () => {
        if (isSaving || changesCount < config.minChanges) return;

        isSaving = true;
        changesCount = 0;

        try {
            const formData = new FormData(form);
            const data = Object.fromEntries(formData);
            
            await ajaxRequest(saveUrl, {
                method: 'POST',
                body: data
            });

            if (config.onSave) {
                config.onSave(data);
            }

            showToast('Data tersimpan otomatis', 'success');
        } catch (error) {
            console.error('Auto-save failed:', error);
            
            if (config.onError) {
                config.onError(error);
            }
            
            showToast('Gagal menyimpan data', 'error');
        } finally {
            isSaving = false;
        }
    };

    const scheduleSave = () => {
        changesCount++;
        clearTimeout(saveTimeout);
        saveTimeout = setTimeout(saveData, config.interval);
    };

    // Listen to form changes
    form.addEventListener('input', scheduleSave);
    form.addEventListener('change', scheduleSave);

    // Before unload warning
    if (config.confirmBeforeUnload) {
        window.addEventListener('beforeunload', (e) => {
            if (changesCount > 0) {
                e.preventDefault();
                e.returnValue = 'Anda memiliki perubahan yang belum disimpan. Yakin ingin meninggalkan halaman?';
            }
        });
    }

    return {
        saveNow: saveData,
        reset: () => {
            changesCount = 0;
            clearTimeout(saveTimeout);
        },
        destroy: () => {
            form.removeEventListener('input', scheduleSave);
            form.removeEventListener('change', scheduleSave);
            window.removeEventListener('beforeunload', () => {});
            clearTimeout(saveTimeout);
        }
    };
};

// Cookie management
const cookieManager = {
    set: (name, value, days = 7, path = '/') => {
        const expires = new Date(Date.now() + days * 864e5).toUTCString();
        document.cookie = `${encodeURIComponent(name)}=${encodeURIComponent(value)}; expires=${expires}; path=${path}`;
    },
    
    get: (name) => {
        const cookies = document.cookie.split(';');
        for (const cookie of cookies) {
            const [key, value] = cookie.trim().split('=');
            if (decodeURIComponent(key) === name) {
                return decodeURIComponent(value);
            }
        }
        return null;
    },
    
    remove: (name, path = '/') => {
        document.cookie = `${encodeURIComponent(name)}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=${path}`;
    }
};

// Local storage dengan expiry
const storageManager = {
    set: (key, value, ttl = null) => {
        const item = {
            value,
            expiry: ttl ? Date.now() + ttl : null
        };
        localStorage.setItem(key, JSON.stringify(item));
    },
    
    get: (key) => {
        const itemStr = localStorage.getItem(key);
        if (!itemStr) return null;
        
        const item = JSON.parse(itemStr);
        
        if (item.expiry && Date.now() > item.expiry) {
            localStorage.removeItem(key);
            return null;
        }
        
        return item.value;
    },
    
    remove: (key) => {
        localStorage.removeItem(key);
    },
    
    clear: () => {
        localStorage.clear();
    }
};

// Format currency
const formatCurrency = (amount, options = {}) => {
    const config = {
        locale: 'id-ID',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
        ...options
    };

    return new Intl.NumberFormat(config.locale, {
        style: 'currency',
        currency: config.currency,
        minimumFractionDigits: config.minimumFractionDigits,
        maximumFractionDigits: config.maximumFractionDigits
    }).format(amount);
};

// Format date
const formatDate = (date, format = 'id-ID') => {
    const d = new Date(date);
    
    if (format === 'relative') {
        const now = new Date();
        const diff = now - d;
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        
        if (minutes < 1) return 'baru saja';
        if (minutes < 60) return `${minutes} menit yang lalu`;
        if (hours < 24) return `${hours} jam yang lalu`;
        if (days < 7) return `${days} hari yang lalu`;
        
        return d.toLocaleDateString('id-ID');
    }
    
    return d.toLocaleDateString(format, {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
};

// Debounce function
const debounce = (func, wait) => {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
};

// Throttle function
const throttle = (func, limit) => {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
};

// Copy to clipboard
const copyToClipboard = async (text) => {
    try {
        await navigator.clipboard.writeText(text);
        showToast('Teks berhasil disalin', 'success');
        return true;
    } catch (err) {
        console.error('Gagal menyalin teks:', err);
        
        // Fallback method
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        
        showToast('Teks berhasil disalin', 'success');
        return true;
    }
};

// Initialize when DOM is loaded
domReady(() => {
    // Initialize animations
    observeElements();
    
    // Initialize tables
    $$('table').forEach((table, index) => {
        if (!table.id) {
            table.id = `table-${index}`;
        }
        enhanceTable(`#${table.id}`, {
            searchable: true,
            sortable: true,
            pagination: true,
            pageSize: 10
        });
    });
    
    // Add smooth scrolling to anchor links
    $$('a[href^="#"]').forEach(link => {
        link.addEventListener('click', (e) => {
            const href = link.getAttribute('href');
            if (href === '#') return;
            
            e.preventDefault();
            const target = $(href);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add ripple effect to buttons
    $$('.btn').forEach(btn => {
        if (btn.hasAttribute('data-no-ripple')) return;
        
        btn.addEventListener('click', function(e) {
            if (this.classList.contains('disabled')) return;
            
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            const ripple = document.createElement('span');
            ripple.className = 'ripple-effect';
            
            Object.assign(ripple.style, {
                position: 'absolute',
                width: `${size}px`,
                height: `${size}px`,
                left: `${x}px`,
                top: `${y}px`,
                background: 'rgba(255, 255, 255, 0.4)',
                borderRadius: '50%',
                transform: 'scale(0)',
                animation: 'ripple 0.6s linear',
                pointerEvents: 'none'
            });
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            setTimeout(() => {
                if (ripple.parentNode) {
                    ripple.parentNode.removeChild(ripple);
                }
            }, 600);
        });
    });
    
    // Mobile menu toggle
    const hamburger = $('.hamburger');
    const navMenu = $('.nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
            
            // Toggle body scroll
            document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (navMenu.classList.contains('active') && 
                !navMenu.contains(e.target) && 
                !hamburger.contains(e.target)) {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
                document.body.style.overflow = '';
            }
        });
    }
    
    // Form validation
    $$('form[data-validate]').forEach(form => {
        enableRealTimeValidation(`#${form.id}`);
        
        form.addEventListener('submit', (e) => {
            const result = validateForm(`#${form.id}`);
            if (!result.isValid) {
                e.preventDefault();
                showAlert('Harap perbaiki error pada form', 'error');
                
                // Scroll ke error pertama
                const firstError = form.querySelector('.error');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstError.focus();
                }
            }
        });
    });
    
    // Auto-save forms
    $$('form[data-autosave]').forEach(form => {
        const saveUrl = form.getAttribute('data-autosave-url');
        if (saveUrl) {
            autoSave(`#${form.id}`, saveUrl, {
                onSave: () => console.log('Auto-save successful'),
                onError: (error) => console.error('Auto-save error:', error)
            });
        }
    });
    
    // Tooltips
    $$('[data-tooltip]').forEach(el => {
        const tooltipText = el.getAttribute('data-tooltip');
        
        el.addEventListener('mouseenter', () => {
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = tooltipText;
            
            const rect = el.getBoundingClientRect();
            
            Object.assign(tooltip.style, {
                position: 'absolute',
                background: 'var(--primary-black)',
                color: 'var(--white)',
                padding: '5px 10px',
                borderRadius: '5px',
                fontSize: '0.875rem',
                zIndex: '10000',
                top: `${rect.bottom + 5}px`,
                left: `${rect.left + rect.width / 2}px`,
                transform: 'translateX(-50%)',
                whiteSpace: 'nowrap',
                pointerEvents: 'none'
            });
            
            document.body.appendChild(tooltip);
            el._tooltip = tooltip;
        });
        
        el.addEventListener('mouseleave', () => {
            if (el._tooltip && el._tooltip.parentNode) {
                el._tooltip.parentNode.removeChild(el._tooltip);
            }
        });
    });
    
    // Lazy loading images
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    if (img.dataset.srcset) {
                        img.srcset = img.dataset.srcset;
                    }
                    img.classList.remove('lazy');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        $$('img.lazy').forEach(img => imageObserver.observe(img));
    }
    
    // Add CSS animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }
        
        @keyframes slideInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes slideOutUp {
            from {
                opacity: 1;
                transform: translateY(0);
            }
            to {
                opacity: 0;
                transform: translateY(-20px);
            }
        }
        
        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes slideOutRight {
            from {
                opacity: 1;
                transform: translateX(0);
            }
            to {
                opacity: 0;
                transform: translateX(20px);
            }
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .field-error {
            color: #dc3545;
            font-size: 0.875rem;
            margin-top: 0.25rem;
            animation: fadeIn 0.3s ease-out;
        }
        
        .alert {
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideInDown 0.3s ease-out;
        }
        
        .alert-icon {
            font-weight: bold;
        }
        
        .alert-close {
            margin-left: auto;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 1.2rem;
            padding: 0;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    `;
    document.head.appendChild(style);
    
    // Initialize tooltips
    console.log('JS utilities initialized successfully');
});

// Export untuk penggunaan module
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        $,
        $$,
        domReady,
        validateForm,
        showAlert,
        showToast,
        showLoading,
        ajaxRequest,
        Modal,
        confirmDialog,
        enhanceTable,
        autoSave,
        cookieManager,
        storageManager,
        formatCurrency,
        formatDate,
        debounce,
        throttle,
        copyToClipboard,
        uploadFile
    };
}