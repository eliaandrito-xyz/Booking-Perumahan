<?php
require_once '../config/session.php';

logout();
?>