 <footer style="
        background: var(--primary-black);
        color: white;
        padding: 3rem 0 1rem;
        margin-top: 0;
    ">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem; margin-bottom: 2rem;">
                <div>
                    <h3 style="color: var(--accent-gold); margin-bottom: 1rem;">Perumahan Kupang</h3>
                    <p style="line-height: 1.6; color: #ccc;">
                        Platform terpercaya untuk menemukan hunian berkualitas di Kota Kupang, Nusa Tenggara Timur.
                    </p>
                </div>
                <div>
                    <h4 style="color: var(--accent-gold); margin-bottom: 1rem;">Menu</h4>
                    <ul style="list-style: none; line-height: 2;">
                        <li><a href="projects.php" style="color: #ccc; text-decoration: none;">Proyek</a></li>
                        <li><a href="units.php" style="color: #ccc; text-decoration: none;">Unit Rumah</a></li>
                        <li><a href="news.php" style="color: #ccc; text-decoration: none;">Berita</a></li>
                        <li><a href="contact.php" style="color: #ccc; text-decoration: none;">Kontak</a></li>
                    </ul>
                </div>
                <div>
                    <h4 style="color: var(--accent-gold); margin-bottom: 1rem;">Kontak</h4>
                    <div style="line-height: 2; color: #ccc;">
                        <p>📍 Jl. Timor Raya, Kupang, NTT</p>
                        <p>📞 (0380) 123-456</p>
                        <p>✉️ info@perumahankupang.com</p>
                    </div>
                </div>
            </div>
            <div style="border-top: 1px solid #444; padding-top: 1rem; text-align: center; color: #ccc;">
                <p>&copy; 2024 Sistem Informasi Perumahan Kota Kupang. All rights reserved.</p>
            </div>
        </div>
    </footer>