-- Database: perumahan_kupang
-- Buat database terlebih dahulu di phpMyAdmin atau MySQL

CREATE DATABASE IF NOT EXISTS perumahan_kupang;
USE perumahan_kupang;

-- Tabel Users
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    role ENUM('admin', 'user') DEFAULT 'user',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabel Developers
CREATE TABLE developers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    website VARCHAR(100),
    logo VARCHAR(255),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabel Housing Projects
CREATE TABLE housing_projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    developer_id INT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    location TEXT NOT NULL,
    address TEXT NOT NULL,
    total_units INT DEFAULT 0,
    available_units INT DEFAULT 0,
    price_range_min DECIMAL(15,2),
    price_range_max DECIMAL(15,2),
    facilities TEXT,
    images TEXT, -- JSON array of image paths
    status ENUM('planning', 'construction', 'ready', 'sold_out') DEFAULT 'planning',
    completion_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (developer_id) REFERENCES developers(id) ON DELETE SET NULL
);

-- Tabel House Units
CREATE TABLE house_units (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    unit_number VARCHAR(20) NOT NULL,
    type VARCHAR(50) NOT NULL, -- Type 36, Type 45, dll
    bedrooms INT DEFAULT 0,
    bathrooms INT DEFAULT 0,
    land_area DECIMAL(8,2), -- m2
    building_area DECIMAL(8,2), -- m2
    price DECIMAL(15,2) NOT NULL,
    description TEXT,
    images TEXT, -- JSON array of image paths
    status ENUM('available', 'booked', 'sold') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES housing_projects(id) ON DELETE CASCADE,
    UNIQUE KEY unique_unit (project_id, unit_number)
);

-- Tabel Bookings
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    unit_id INT NOT NULL,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    customer_name VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    customer_email VARCHAR(100),
    customer_address TEXT,
    booking_fee DECIMAL(15,2) DEFAULT 0,
    notes TEXT,
    status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (unit_id) REFERENCES house_units(id) ON DELETE CASCADE
);

-- Tabel News/Articles
CREATE TABLE news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    excerpt TEXT,
    image VARCHAR(255),
    author_id INT,
    category ENUM('news', 'tips', 'market_update', 'regulation') DEFAULT 'news',
    status ENUM('draft', 'published') DEFAULT 'draft',
    published_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Tabel Contact Messages
CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('unread', 'read', 'replied') DEFAULT 'unread',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user
INSERT INTO users (username, email, password, full_name, role) VALUES 
('admin', 'admin@perumahankupang.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin');
-- Password: password

-- Insert sample developers
INSERT INTO developers (name, description, address, phone, email) VALUES 
('PT. Kupang Indah Property', 'Developer terpercaya di Kota Kupang dengan pengalaman lebih dari 10 tahun', 'Jl. Timor Raya No. 123, Kupang', '0380-123456', 'info@kupangindah.com'),
('PT. Nusa Tenggara Development', 'Spesialis perumahan modern dan terjangkau', 'Jl. El Tari No. 45, Kupang', '0380-789012', 'contact@ntdevelopment.com');

-- Insert sample housing projects
INSERT INTO housing_projects (developer_id, name, description, location, address, total_units, available_units, price_range_min, price_range_max, facilities, status) VALUES 
(1, 'Kupang Golden Residence', 'Perumahan mewah dengan fasilitas lengkap di jantung kota Kupang', 'Kelapa Lima', 'Jl. Veteran, Kelapa Lima, Kupang', 150, 120, 350000000, 750000000, 'Security 24 jam, Taman bermain, Kolam renang, Masjid, Minimarket', 'ready'),
(1, 'Timor Garden Estate', 'Hunian asri dengan konsep green living', 'Oebobo', 'Jl. Timor Raya KM 8, Oebobo, Kupang', 200, 180, 250000000, 500000000, 'Taman hijau, Jogging track, Playground, Pos keamanan', 'construction'),
(2, 'Nusa Indah Residence', 'Perumahan terjangkau untuk keluarga muda', 'Alak', 'Jl. Frans Seda, Alak, Kupang', 100, 85, 180000000, 350000000, 'Masjid, Playground, Pos satpam, Area parkir luas', 'ready');

-- Insert sample house units
INSERT INTO house_units (project_id, unit_number, type, bedrooms, bathrooms, land_area, building_area, price, status) VALUES 
(1, 'A-01', 'Type 45', 2, 1, 90.00, 45.00, 350000000, 'available'),
(1, 'A-02', 'Type 60', 3, 2, 120.00, 60.00, 500000000, 'available'),
(1, 'B-01', 'Type 75', 3, 2, 150.00, 75.00, 750000000, 'booked'),
(2, 'T-01', 'Type 36', 2, 1, 72.00, 36.00, 250000000, 'available'),
(2, 'T-02', 'Type 45', 2, 1, 90.00, 45.00, 320000000, 'available'),
(3, 'N-01', 'Type 30', 2, 1, 60.00, 30.00, 180000000, 'available'),
(3, 'N-02', 'Type 36', 2, 1, 72.00, 36.00, 220000000, 'sold');

-- Insert sample news
INSERT INTO news (title, content, excerpt, author_id, category, status, published_at) VALUES 
('Perkembangan Properti Kupang 2024', 'Industri properti di Kota Kupang mengalami pertumbuhan yang signifikan...', 'Pertumbuhan properti Kupang mencapai 15% di tahun 2024', 1, 'market_update', 'published', NOW()),
('Tips Memilih Rumah Idaman', 'Berikut adalah tips-tips penting dalam memilih rumah yang tepat...', 'Panduan lengkap memilih rumah sesuai kebutuhan dan budget', 1, 'tips', 'published', NOW());