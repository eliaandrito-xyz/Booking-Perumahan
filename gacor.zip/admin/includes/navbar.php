<?php

require_once '../config/database.php';
require_once '../config/session.php';



?>


<style>
  .logo {
    display: flex;
    align-items: center;
    gap: 12px;
    text-decoration: none;
    font-weight: 600;
    color: #ffd700;
}

.logo-img {
    width: 44px;
    height: 44px;
    border-radius: 50%;
    object-fit: cover;
    background: #fff;
    box-shadow: 0 2px 8px rgba(0,0,0,.15);
}



</style>


<header class="header">
    <div class="header-container">
        <!-- Logo -->
       <a href="index.php" class="logo">
    <img src="img/logo.png" alt="PT. Gracia Jaya Permai" class="logo-img">
    <span>Admin Panel</span>
</a>


        <!-- Hamburger Menu Button -->
        <button class="hamburger" aria-label="Toggle navigation">
            <span></span>
            <span></span>
            <span></span>
        </button>

        <!-- Navigation Menu -->
        <nav>
            <ul class="nav-menu">
                <li><a href="index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
                    Dashboard
                </a></li>
                <li><a href="projects.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'projects.php' ? 'active' : ''; ?>">
                    Proyek
                </a></li>
                <li><a href="units.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'units.php' ? 'active' : ''; ?>">
                    Unit
                </a></li>
                 <li><a href="bookings.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'bookings.php' ? 'active' : ''; ?>">
                    Booking
                </a></li>
                  <li><a href="users.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
                    Users
                </a></li>
                 
                <li><a href="news.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'news.php' ? 'active' : ''; ?>">
                    Berita
                </a></li>
                <li><a href="messages.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'messages.php' ? 'active' : ''; ?>">
                    Pesan
                </a></li>
                <?php if (isLoggedIn()): ?>
                   
                    <li><a href="logout.php" class="nav-link">
                        Logout
                    </a></li>
                <?php else: ?>
                    <li><a href="login.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'login.php' ? 'active' : ''; ?>">
                        Login
                    </a></li>
                    <li><a href="register.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'register.php' ? 'active' : ''; ?>">
                        Daftar
                    </a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>
